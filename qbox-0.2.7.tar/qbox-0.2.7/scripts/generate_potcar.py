#!/usr/bin/env python3
import os
import sys

def get_elements_from_poscar(poscar_file='POSCAR'):
    """从POSCAR中提取元素列表，并映射到VASP对应的POTCAR名称"""
    with open(poscar_file, 'r') as f:
        lines = f.readlines()    
    elements_line = lines[5].strip()
    elements = elements_line.split()    
    # 元素映射字典（和原逻辑完全一致）
    element_mapping = {
        "Li": "Li_sv", "Na": "Na_pv", "K": "K_sv", "Ca": "Ca_sv",
        "Sc": "Sc_sv", "Ti": "Ti_sv", "V": "V_sv", "Cr": "Cr_pv",
        "Mn": "Mn_pv", "Ga": "Ga_d", "Ge": "Ge_d", "Rb": "Rb_sv",
        "Sr": "Sr_sv", "Y": "Y_sv", "Zr": "Zr_sv", "Nb": "Nb_sv",
        "Mo": "Mo_sv", "Tc": "Tc_pv", "Ru": "Ru_pv", "Rh": "Rh_pv",
        "In": "In_d", "Sn": "Sn_d", "Cs": "Cs_sv", "Ba": "Ba_sv",
        "Pr": "Pr_3", "Nd": "Nd_3", "Pm": "Pm_3", "Sm": "Sm_3",
        "Eu": "Eu_2", "Gd": "Gd_3", "Tb": "Tb_3", "Dy": "Dy_3",
        "Ho": "Ho_3", "Er": "Er_3", "Tm": "Tm_3", "Yb": "Yb_2",
        "Lu": "Lu_3", "Hf": "Hf_pv", "Ta": "Ta_pv", "W": "W_sv",
        "Tl": "Tl_d", "Pb": "Pb_d", "Bi": "Bi_d", "Po": "Po_d",
        "Fr": "Fr_sv", "Ra": "Ra_sv"
    }    
    mapped_elements = []
    for element in elements:
        if element in element_mapping:
            mapped_elements.append(element_mapping[element])
        else:
            mapped_elements.append(element)    
    return mapped_elements

def generate_potcar(elements, potcar_dir, output_file='POTCAR'):
    """拼接指定元素的POTCAR文件"""
    with open(output_file, 'w') as potcar:
        for element in elements:
            potcar_path = os.path.join(potcar_dir, element, 'POTCAR')
            if not os.path.exists(potcar_path):
                raise FileNotFoundError(f"{potcar_path} does not exist！")
            with open(potcar_path, 'r') as potcar_part:
                potcar.write(potcar_part.read())

if __name__ == '__main__':
    try:
        # 从命令行参数获取POTCAR_DIR（替代原Bash变量$POTCAR_DIR）
        potcar_dir = sys.argv[1]
        poscar_file = 'POSCAR'
        output_file = 'POTCAR'
        
        if not os.path.exists(poscar_file):
            print("ERROR: POSCAR file not found!")
            sys.exit(1)            
        elements = get_elements_from_poscar(poscar_file)
        print("Elements in POSCAR:", elements)
        generate_potcar(elements, potcar_dir, output_file)        
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)