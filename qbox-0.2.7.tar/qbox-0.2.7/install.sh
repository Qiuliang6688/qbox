#!/bin/bash

echo " "
path=`cd $(dirname $0); pwd -P`
    echo "#qbox:$path
     export qboxpath=$path
     export qboxpbepath=*****
     export PATH=$path:\$PATH
     export PATH=$path/scripts/vtstscripts:\$PATH" >> $HOME/.bashrc
    source $HOME/.bashrc
    echo -e "you have install qbox successfully\n"
    echo -e "!!!change ***** in .bashrc to your PBE path!!!"
echo " "
