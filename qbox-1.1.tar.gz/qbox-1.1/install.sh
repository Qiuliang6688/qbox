#!/bin/bash

echo ""

qbox_script_path=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)
cat >> "$HOME/.bashrc" << EOF
export qboxpath=${qbox_script_path}
export qboxpbepath=*****  # 需替换为你的PBE实际路径
export PATH=${qbox_script_path}:\$PATH
export PATH=${qbox_script_path}/exefile/Tools/USERTooLs/vtstscripts:\$PATH
EOF
source "$HOME/.bashrc"
chmod +x ./qbox
chmod +x ./bin/*
chmod +x ./bin/input/*

echo -e "\n你已成功安装qbox！请完成以下最终配置步骤："
echo -e "1. 编辑.bashrc文件：vi ~/.bashrc"
echo -e "2. 将 export qboxpbepath=***** 中的 ***** 替换为你的PBE实际路径"
echo -e "3. 生效配置：source ~/.bashrc"

echo ""
