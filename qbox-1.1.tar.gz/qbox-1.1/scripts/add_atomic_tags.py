#!/usr/bin/env python3

# 核心逻辑：给POSCAR添加原子双索引标签
with open('POSCAR', 'r') as f:
    lines = f.readlines()

elements = lines[5].split()
elem_counts = list(map(int, lines[6].split()))

# 确定坐标起始行
coord_start = 8
if lines[7].strip().lower() == 'selective dynamics':
    coord_start = 9  
elif lines[7].strip().lower() in ['direct', 'cartesian']:
    coord_start = 8
else:
    coord_start = 8

new_lines = lines[:coord_start]  # 保留坐标行之前的内容
global_atom_idx = 1  # 全局原子索引

# 遍历每个元素及其原子数，添加标签
for elem, elem_count in zip(elements, elem_counts):
    elem_internal_idx = 1  # 元素内原子索引
    for _ in range(elem_count):
        orig_line = lines[coord_start].strip()
        if not orig_line:
            new_lines.append('\n')
            coord_start += 1
            continue
        
        # 拆分坐标部分和注释部分
        parts = orig_line.split()
        if len(parts) >= 6 and parts[3] in ['T', 'F']:
            coord_part = parts[:6]
            comment_part = ' '.join(parts[6:]) if len(parts) > 6 else ''
        else:
            coord_part = parts[:3]
            comment_part = ' '.join(parts[3:]) if len(parts) > 3 else ''
        
        # 构建双索引标签
        dual_tag = f"#Tot {global_atom_idx} {elem} {elem_internal_idx}"
        # 拼接新行（保留原有注释，添加标签）
        if comment_part:
            new_line = ' '.join(coord_part) + ' ' + dual_tag + ' ' + comment_part + '\n'
        else:
            new_line = ' '.join(coord_part) + ' ' + dual_tag + '\n'
        
        new_lines.append(new_line)
        coord_start += 1
        global_atom_idx += 1
        elem_internal_idx += 1  

# 追加坐标行之后的剩余内容
new_lines.extend(lines[coord_start:])

# 写入修改后的POSCAR
with open('POSCAR', 'w') as f:
    f.writelines(new_lines)