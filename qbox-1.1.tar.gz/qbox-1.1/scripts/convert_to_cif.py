#!/usr/bin/env python3
import sys
import os

def convert_structure_to_cif(input_file, output_file):
    """将任意结构文件转换为CIF格式"""
    try:
        from ase.io import read, write
        # 读取输入结构文件
        atoms = read(input_file)
        # 写入CIF文件
        write(output_file, atoms, format='cif')
        print(f"Successfully converted to CIF: {output_file}")
    except ImportError:
        print("ERROR: Please install ASE first: pip install ase")
        sys.exit(1)
    except Exception as e:
        print(f"Conversion failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    # 从命令行参数获取输入/输出文件路径
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    # 执行转换逻辑
    convert_structure_to_cif(input_file, output_file)