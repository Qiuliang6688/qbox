#!/usr/bin/env python3
import sys
import os

def convert_structure_to_gro(input_file, output_file):
    """将任意结构文件转换为GROMACS的GRO格式"""
    try:
        from ase.io import read, write
        # 读取输入结构文件
        atoms = read(input_file)
        # 写入GRO文件（format='gromacs'对应GRO格式）
        write(output_file, atoms, format='gromacs')
        print(f"Successfully converted to GRO: {output_file}")
    except ImportError:
        print("ERROR: Please install ASE first: pip install ase")
        sys.exit(1)
    except Exception as e:
        print(f"Conversion failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    # 从命令行参数获取输入/输出文件路径
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    # 执行转换逻辑
    convert_structure_to_gro(input_file, output_file)