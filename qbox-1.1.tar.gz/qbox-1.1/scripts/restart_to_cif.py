#!/usr/bin/env python3
"""
Convert CP2K .restart file to .cif format
Usage: restart2cif input.restart output.cif
"""

import sys
from ase.io import read, write

def restart_to_cif(input_file, output_file):
    """
    Convert CP2K restart file to CIF format
    """
    try:
        atoms = read(input_file, format='cp2k-restart')
        write(output_file, atoms, format='cif')
        print(f"Successfully converted {input_file} to {output_file}")
    except Exception as e:
        print(f"Error during conversion: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: restart2cif input.restart output.cif")
        sys.exit(1)

    restart_to_cif(sys.argv[1], sys.argv[2])
