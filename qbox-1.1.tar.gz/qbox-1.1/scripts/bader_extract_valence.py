#!/usr/bin/env python3
import re

def extract_valence_electrons():
    """从POTCAR文件中提取各元素的价电子数（ZVAL）"""
    try:
        with open('POTCAR', 'r') as f:
            content = f.read()

        # 按空行分割POTCAR中不同元素的段
        potcar_sections = re.split(r'\n\s*\n', content)
        
        element_valence = {}
        
        for section in potcar_sections:
            if not section.strip():
                continue
      
            # 匹配元素名称（从TITEL行提取）
            element_match = re.search(r'TITEL\s*=\s*PAW_[A-Za-z_]+\s+([A-Za-z]{1,3})', section)
            if element_match:
                element = element_match.group(1)
                # 匹配ZVAL（价电子数）
                zval_match = re.search(r'ZVAL\s*=\s*([\d.]+)', section)
                if zval_match:
                    valence = float(zval_match.group(1))
                    element_valence[element] = valence
        
        return element_valence
    
    except Exception as e:
        print(f"ERROR reading POTCAR: {e}")
        return {}

# 执行函数并打印结果（和原逻辑一致）
if __name__ == '__main__':
    valence_info = extract_valence_electrons()

    if valence_info:
        print("Valence electrons from POTCAR:")
        for element, valence in valence_info.items():
            print(f"  {element}: {valence:.1f}")
    else:
        print("Could not extract valence electron information from POTCAR")