#!/bin/bash
set -euo pipefail

# ==============================================
# 核心配置：轨道-列索引映射（VASP标准DOSCAR格式）
# ==============================================
# 非自旋极化：列索引从2开始（第1列为E-Ef）
# 自旋极化：列索引为 up(奇数列)、down(偶数列)，从2开始
declare -A ORBITAL_COL_NOSPIN=(
    ["s"]=2
    ["px"]=3
    ["py"]=4
    ["pz"]=5
    ["dxy"]=6
    ["dxz"]=7
    ["dyz"]=8
    ["dz2"]=9
    ["dx2-y2"]=10  # 别名dx2、dxy2
)
# 自旋极化列映射（up=原列，down=原列+1）
declare -A ORBITAL_COL_SPIN=(
    ["s_up"]=2
    ["s_down"]=3
    ["px_up"]=4
    ["px_down"]=5
    ["py_up"]=6
    ["py_down"]=7
    ["pz_up"]=8
    ["pz_down"]=9
    ["dxy_up"]=10
    ["dxy_down"]=11
    ["dxz_up"]=12
    ["dxz_down"]=13
    ["dyz_up"]=14
    ["dyz_down"]=15
    ["dz2_up"]=16
    ["dz2_down"]=17
    ["dx2-y2_up"]=18
    ["dx2-y2_down"]=19
)
# 轨道别名映射（兼容用户简化输入）
declare -A ORBITAL_ALIAS=(
    ["dx2"]="dx2-y2"
    ["dxy2"]="dx2-y2"
    ["d_z2"]="dz2"
    ["d_x2"]="dx2-y2"
)

# ==============================================
# 预处理：检查依赖和输入文件
# ==============================================
check_dependency() {
    local deps=("bc" "awk" "sed" "grep")
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            echo "错误：未找到必需工具 $dep，请先安装（如 sudo apt install $dep）"
            exit 1
        fi
    done
}

check_input_files() {
    if [ ! -f "DOSCAR" ]; then
        echo "错误：当前目录未找到 DOSCAR 文件"
        exit 1
    fi
    if [ ! -f "POSCAR" ]; then
        echo "错误：当前目录未找到 POSCAR 文件（用于元素识别）"
        exit 1
    fi
}

# ==============================================
# 步骤1：解析 DOSCAR 和 POSCAR 核心信息
# ==============================================
parse_doscar() {
    echo "正在解析 DOSCAR 信息..."
    natoms=$(head -n1 DOSCAR | awk '{print $1}')
    line6=$(sed -n '6p' DOSCAR)
    nedos=$(echo "$line6" | awk '{print $3}')
    efermi=$(echo "$line6" | awk '{print $4}')
    # 判断自旋极化（参考Python脚本的列数判断逻辑）
    total_dos_line=$(sed -n '7p' DOSCAR)
    ncols_total=$(echo "$total_dos_line" | awk '{print NF}')
    if [ $ncols_total -eq 7 ] || [ $ncols_total -eq 19 ] || [ $ncols_total -eq 9 ] || [ $ncols_total -eq 33 ]; then
        spin_polarized=1
        echo "  自旋极化：是（列数：$ncols_total）"
    else
        spin_polarized=0
        echo "  自旋极化：否（列数：$ncols_total）"
    fi
    # 原子分态密度列数（每个原子的DOS列数）
    atom_dos_sample=$(sed -n "$((7+nedos+2))p" DOSCAR)  # 第一个原子的第一行DOS
    ncols_atom=$(echo "$atom_dos_sample" | awk '{print NF}')
    echo "  原子数：$natoms"
    echo "  DOS点数：$nedos"
    echo "  费米能级：$efermi eV"
    echo "  原子分态密度列数：$ncols_atom"
}

parse_poscar() {
    echo "正在解析 POSCAR 元素信息..."
    # 兼容VASP标准格式（第6行元素，第7行原子数）
    for line_num in 6 5 7; do
        elem_line=$(sed -n "${line_num}p" POSCAR | xargs)
        if [[ $elem_line =~ ^[A-Za-z]+([[:space:]]+[A-Za-z]+)*$ ]]; then
            elements=($elem_line)
            count_line=$(sed -n "$((line_num+1))p" POSCAR | xargs)
            atoms_count=($count_line)
            break
        fi
    done
    # 生成原子-元素映射（原子编号1-based）
    atom_elements=()
    idx=0
    for i in "${!elements[@]}"; do
        elem=${elements[$i]}
        count=${atoms_count[$i]}
        for ((j=0; j<count; j++)); do
            atom_elements[$((idx+1))]=$elem
            idx=$((idx+1))
        done
    done
    # 验证原子数匹配
    if [ $idx -ne $natoms ]; then
        echo "错误：POSCAR 元素总数（$idx）与 DOSCAR 原子数（$natoms）不匹配"
        exit 1
    fi
    echo "  元素列表：${elements[*]}"
}

# ==============================================
# 工具函数：轨道验证与列索引转换
# ==============================================
validate_element() {
    local target_elem=$1
    if ! [[ " ${elements[@]} " =~ " ${target_elem} " ]]; then
        echo "错误：元素 $target_elem 不在体系中（可用元素：${elements[*]}）"
        exit 1
    fi
}

resolve_orbital_alias() {
    local orbital=$1
    echo "${ORBITAL_ALIAS[$orbital]:-$orbital}"  # 无别名则返回原轨道
}

validate_orbitals() {
    local orbitals=($@)
    local valid_orbitals=("${!ORBITAL_COL_NOSPIN[@]}")
    for orb in "${orbitals[@]}"; do
        local resolved_orb=$(resolve_orbital_alias "$orb")
        if ! [[ " ${valid_orbitals[@]} " =~ " ${resolved_orb} " ]]; then
            echo "错误：无效轨道 $orb（可用轨道：${valid_orbitals[*]}）"
            exit 1
        fi
    done
}

get_orbital_columns() {
    local orbitals=($@)
    local cols=()
    for orb in "${orbitals[@]}"; do
        local resolved_orb=$(resolve_orbital_alias "$orb")
        if [ $spin_polarized -eq 0 ]; then
            cols+=(${ORBITAL_COL_NOSPIN[$resolved_orb]})
        else
            cols+=(${ORBITAL_COL_SPIN["${resolved_orb}_up"]})
            cols+=(${ORBITAL_COL_SPIN["${resolved_orb}_down"]})
        fi
    done
    echo "${cols[@]}"
}

# ==============================================
# 步骤2：核心数据提取函数（修改为保留轨道分量）
# ==============================================
extract_tdos() {
    echo "正在提取总态密度（TDOS）..."
    start=7
    end=$((start + nedos - 1))
    echo "# E-Ef (eV)  Total_DOS" > tdos.tmp
    sed -n "${start},${end}p" DOSCAR | while read -r line; do
        e=$(echo "$line" | awk '{print $1}')
        e_ef=$(echo "$e - $efermi" | bc -l)
        if [ $spin_polarized -eq 0 ]; then
            dos_sum=$(echo "$line" | awk '{sum=0; for(i=2;i<=NF;i++) sum+=$i; print sum}')
        else
            up_sum=$(echo "$line" | awk '{sum=0; for(i=2;i<=NF;i+=2) sum+=$i; print sum}')
            down_sum=$(echo "$line" | awk '{sum=0; for(i=3;i<=NF;i+=2) sum+=$i; print sum}')
            dos_sum=$(echo "$up_sum - $down_sum" | bc -l)
        fi
        printf "%.8f  %.8f\n" "$e_ef" "$dos_sum" >> tdos.tmp
    done
}

extract_element_orbital_pdos() {
    echo "正在提取元素轨道分态密度（含分量）..."
    atom_dos_start=$((7 + nedos))  # 原子分态密度起始行
    # 初始化元素临时文件（保留所有轨道分量）
    declare -A elem_files
    for elem in "${elements[@]}"; do
        tmp_file="${elem}_orbital_pdos.tmp"
        elem_files[$elem]=$tmp_file
        # 生成表头
        local header="# E-Ef (eV)"
        if [ $spin_polarized -eq 0 ]; then
            header+="  s  px  py  pz  dxy  dxz  dyz  dz2  dx2-y2"
        else
            header+="  s_up  s_down  px_up  px_down  py_up  py_down  pz_up  pz_down"
            header+="  dxy_up  dxy_down  dxz_up  dxz_down  dyz_up  dyz_down  dz2_up  dz2_down  dx2-y2_up  dx2-y2_down"
        fi
        echo "$header" > "$tmp_file"
    done

    # 处理每个原子的分态密度
    for ((atom=1; atom<=natoms; atom++)); do
        elem=${atom_elements[$atom]}
        tmp_file=${elem_files[$elem]}
        start=$((atom_dos_start + (atom-1)*nedos))
        end=$((atom_dos_start + atom*nedos - 1))
        
        # 提取并累加该原子的轨道分量数据
        sed -n "${start},${end}p" DOSCAR | while read -r line; do
            e=$(echo "$line" | awk '{print $1}')
            e_ef=$(echo "$e - $efermi" | bc -l)
            # 提取所有轨道分量列（非自旋：2-10列；自旋：2-19列）
            if [ $spin_polarized -eq 0 ]; then
                orbitals_data=$(echo "$line" | awk '{for(i=2;i<=10;i++) printf "%.8f ", $i}')
            else
                orbitals_data=$(echo "$line" | awk '{for(i=2;i<=19;i++) printf "%.8f ", $i}')
            fi
            # 写入原子临时文件，后续合并
            printf "%.8f  %s\n" "$e_ef" "$orbitals_data" >> "${tmp_file}_atom$atom"
        done
    done

    # 合并同一元素的所有原子数据
    for elem in "${elements[@]}"; do
        tmp_file=${elem_files[$elem]}
        atom_files=("${tmp_file}_atom"*)
        # 按能量列累加所有原子的轨道数据
        awk '
        BEGIN { prev_e = "" }
        {
            e = $1
            if (e != prev_e) {
                if (prev_e != "") print line
                line = $0
                prev_e = e
            } else {
                split(line, arr)
                for (i=2; i<=NF; i++) arr[i] += $i
                line = ""
                for (i=1; i<=NF; i++) line = line sprintf("%.8f ", arr[i])
                sub(/ $/, "", line)
            }
        }
        END { print line }
        ' "${atom_files[@]}" > "$tmp_file"
        rm -f "${atom_files[@]}"  # 清理原子临时文件
    done
}

# ==============================================
# 新增功能4：自定义轨道叠加PDOS
# ==============================================
extract_custom_orbital_pdos() {
    read -p "请输入目标元素（如 Ni、O）：" target_elem
    validate_element "$target_elem"
    read -p "请输入需要叠加的轨道（用逗号分隔，如 dx2,dyz,pz）：" orbital_str
    local orbitals=($(echo "$orbital_str" | tr ',' ' '))
    validate_orbitals "${orbitals[@]}"
    local orbital_cols=($(get_orbital_columns "${orbitals[@]}"))
    local tmp_file="${target_elem}_orbital_pdos.tmp"
    local output_file="${target_elem}_custom_orbital_pdos.dat"

    echo "正在叠加 ${target_elem} 的轨道：${orbitals[*]}..."
    # 生成输出文件
    if [ $spin_polarized -eq 0 ]; then
        echo "# E-Ef (eV)  Custom_Orbital_DOS (${orbitals[*]})" > "$output_file"
        # 累加指定轨道列
        awk -v cols="${orbital_cols[*]}" '
        NR == 1 { next }  # 跳过表头
        {
            sum = 0
            split(cols, c_arr)
            for (i in c_arr) sum += $c_arr[i]
            printf "%.8f  %.8f\n", $1, sum
        }
        ' "$tmp_file" >> "$output_file"
    else
        echo "# E-Ef (eV)  Custom_Orbital_DOS_up  Custom_Orbital_DOS_down  Custom_Orbital_DOS_net" > "$output_file"
        # 累加up列和down列（轨道列按up,down成对排列）
        awk -v cols="${orbital_cols[*]}" '
        NR == 1 { next }
        {
            up_sum = 0
            down_sum = 0
            split(cols, c_arr)
            for (i=1; i<=length(c_arr); i+=2) {
                up_sum += $c_arr[i]
                down_sum += $c_arr[i+1]
            }
            net_sum = up_sum - down_sum
            printf "%.8f  %.8f  %.8f  %.8f\n", $1, up_sum, down_sum, net_sum
        }
        ' "$tmp_file" >> "$output_file"
    fi
    echo "✅ 成功输出自定义轨道叠加文件：$output_file"
}

# ==============================================
# 新增功能5：计算态密度中心（参考Perl脚本积分逻辑）
# ==============================================
calculate_dos_center() {
    read -p "请输入目标元素（如 Ni、O）：" target_elem
    validate_element "$target_elem"
    read -p "请输入目标轨道（如 d、s、dx2-y2，输入d/p/s代表全轨道）：" orbital
    local resolved_orb=$(resolve_orbital_alias "$orbital")
    local tmp_file="${target_elem}_orbital_pdos.tmp"
    local output_file="${target_elem}_${orbital}_center.dat"

    # 处理轨道组（s/p/d全轨道）
    local orbital_group=()
    if [ "$resolved_orb" = "s" ]; then
        orbital_group=("s")
    elif [ "$resolved_orb" = "p" ]; then
        orbital_group=("px" "py" "pz")
    elif [ "$resolved_orb" = "d" ]; then
        orbital_group=("dxy" "dxz" "dyz" "dz2" "dx2-y2")
    else
        validate_orbitals "$resolved_orb"
        orbital_group=("$resolved_orb")
    fi
    local orbital_cols=($(get_orbital_columns "${orbital_group[@]}"))
    echo "正在计算 ${target_elem} ${orbital} 轨道的态密度中心（包含轨道：${orbital_group[*]}）..."

    # 询问能量范围
    read -p "请输入能量范围（格式：emin,emax，直接回车使用全范围）：" energy_range
    local emin=""
    local emax=""
    if [ -n "$energy_range" ]; then
        emin=$(echo "$energy_range" | cut -d',' -f1)
        emax=$(echo "$energy_range" | cut -d',' -f2)
        if ! [[ "$emin" =~ ^[-+]?[0-9]*\.?[0-9]+$ && "$emax" =~ ^[-+]?[0-9]*\.?[0-9]+$ ]]; then
            echo "错误：能量范围格式无效（示例：-5,5）"
            exit 1
        fi
        if (( $(echo "$emin > $emax" | bc -l) )); then
            echo "错误：emin（$emin）大于 emax（$emax）"
            exit 1
        fi
        echo "  能量范围：$emin eV 到 $emax eV"
    else
        # 获取全范围能量
        emin=$(awk 'NR>1 {print $1; exit}' "$tmp_file")
        emax=$(awk 'NR>1 {e=$1} END {print e}' "$tmp_file")
        echo "  能量范围：全范围（$emin eV 到 $emax eV）"
    fi

    # 提取DOS数据并计算积分（参考Perl脚本的∫E*DOS / ∫DOS）
    echo "正在积分计算态密度中心..."
    if [ $spin_polarized -eq 0 ]; then
        # 非自旋：累加轨道列的DOS
        awk -v cols="${orbital_cols[*]}" -v emin="$emin" -v emax="$emax" '
        BEGIN { numerator = 0; denominator = 0 }
        NR == 1 { next }
        $1 >= emin && $1 <= emax {
            sum_dos = 0
            split(cols, c_arr)
            for (i in c_arr) sum_dos += $c_arr[i]
            numerator += $1 * sum_dos
            denominator += sum_dos
        }
        END {
            if (denominator == 0) {
                print "错误：积分区间内DOS总和为零" > "/dev/stderr"
                exit 1
            }
            center = numerator / denominator
            printf "态密度中心：%.6f eV\n", center
            printf "积分区间：%.2f eV 到 %.2f eV\n", emin, emax
            printf "DOS总和（分母）：%.6f\n", denominator
            printf "E*DOS积分（分子）：%.6f\n", numerator
        }
        ' "$tmp_file" | tee "$output_file"
    else
        # 自旋极化：计算净DOS中心
        awk -v cols="${orbital_cols[*]}" -v emin="$emin" -v emax="$emax" '
        BEGIN { numerator = 0; denominator = 0 }
        NR == 1 { next }
        $1 >= emin && $1 <= emax {
            up_sum = 0; down_sum = 0
            split(cols, c_arr)
            for (i=1; i<=length(c_arr); i+=2) {
                up_sum += $c_arr[i]
                down_sum += $c_arr[i+1]
            }
            net_dos = up_sum - down_sum
            numerator += $1 * net_dos
            denominator += net_dos
        }
        END {
            if (denominator == 0) {
                print "错误：积分区间内净DOS总和为零" > "/dev/stderr"
                exit 1
            }
            center = numerator / denominator
            printf "净态密度中心：%.6f eV\n", center
            printf "积分区间：%.2f eV 到 %.2f eV\n", emin, emax
            printf "净DOS总和（分母）：%.6f\n", denominator
            printf "E*净DOS积分（分子）：%.6f\n", numerator
        }
        ' "$tmp_file" | tee "$output_file"
    fi
    echo "✅ 结果已保存到文件：$output_file"
}

# ==============================================
# 步骤3：用户交互（新增选项4、5）
# ==============================================
user_interaction() {
    echo -e "\n===== DOSCAR 态密度分析工具 ====="
    echo "请选择输出类型："
    echo "1. 总态密度（TDOS）→ tdos.dat"
    echo "2. 按元素分态密度（PDOS）→ 元素_pdos.dat（含s/p/d总贡献）"
    echo "3. 特定元素的轨道分态密度 → 元素_s/p/d_pdos.dat"
    echo "4. 特定元素的自定义轨道叠加PDOS → 元素_custom_orbital_pdos.dat"
    echo "5. 计算特定元素轨道的态密度中心（如d带中心）→ 元素_轨道_center.dat"
    read -p "请输入选项（1/2/3/4/5）：" choice

    case $choice in
        1)
            mv tdos.tmp tdos.dat
            echo -e "\n✅ 成功输出总态密度文件：tdos.dat"
            ;;
        2)
            # 从轨道分量文件合并s/p/d总贡献
            for elem in "${elements[@]}"; do
                local orbital_tmp="${elem}_orbital_pdos.tmp"
                local pdos_file="${elem}_pdos.dat"
                if [ $spin_polarized -eq 0 ]; then
                    echo "# E-Ef (eV)  s  p  d  Total" > "$pdos_file"
                    awk '
                    NR == 1 { next }
                    {
                        s = $2
                        p = $3 + $4 + $5
                        d = $6 + $7 + $8 + $9 + $10
                        total = s + p + d
                        printf "%.8f  %.8f  %.8f  %.8f  %.8f\n", $1, s, p, d, total
                    }
                    ' "$orbital_tmp" >> "$pdos_file"
                else
                    echo "# E-Ef (eV)  s_up  s_down  p_up  p_down  d_up  d_down  Net_Total" > "$pdos_file"
                    awk '
                    NR == 1 { next }
                    {
                        s_up = $2; s_down = $3
                        p_up = $4 + $6 + $8; p_down = $5 + $7 + $9
                        d_up = $10 + $12 + $14 + $16 + $18; d_down = $11 + $13 + $15 + $17 + $19
                        net_total = (s_up + p_up + d_up) - (s_down + p_down + d_down)
                        printf "%.8f  %.8f  %.8f  %.8f  %.8f  %.8f  %.8f  %.8f\n", 
                            $1, s_up, s_down, p_up, p_down, d_up, d_down, net_total
                    }
                    ' "$orbital_tmp" >> "$pdos_file"
                fi
                echo "✅ 成功输出 ${elem} 分态密度文件：${pdos_file}"
            done
            ;;
        3)
            read -p "请输入目标元素（如 Ni、O）：" target_elem
            validate_element "$target_elem"
            local orbital_tmp="${target_elem}_orbital_pdos.tmp"
            # 输出s/p/d总轨道PDOS
            if [ $spin_polarized -eq 0 ]; then
                awk '{print $1, $2}' "$orbital_tmp" > "${target_elem}_s_pdos.dat"
                awk '{p=$3+$4+$5; print $1, p}' "$orbital_tmp" > "${target_elem}_p_pdos.dat"
                awk '{d=$6+$7+$8+$9+$10; print $1, d}' "$orbital_tmp" > "${target_elem}_d_pdos.dat"
            else
                awk '{print $1, $2, $3}' "$orbital_tmp" > "${target_elem}_s_pdos.dat"
                awk '{p_up=$4+$6+$8; p_down=$5+$7+$9; print $1, p_up, p_down}' "$orbital_tmp" > "${target_elem}_p_pdos.dat"
                awk '{d_up=$10+$12+$14+$16+$18; d_down=$11+$13+$15+$17+$19; print $1, d_up, d_down}' "$orbital_tmp" > "${target_elem}_d_pdos.dat"
            fi
            echo -e "\n✅ 成功输出 ${target_elem} 轨道分态密度文件："
            echo "   - ${target_elem}_s_pdos.dat（s轨道）"
            echo "   - ${target_elem}_p_pdos.dat（p轨道）"
            echo "   - ${target_elem}_d_pdos.dat（d轨道）"
            ;;
        4)
            extract_custom_orbital_pdos
            ;;
        5)
            calculate_dos_center
            ;;
        *)
            echo "错误：无效选项！请输入 1-5"
            exit 1
            ;;
    esac
}

# ==============================================
# 主程序执行流程
# ==============================================
main() {
    echo "===== DOSCAR 态密度分析脚本（增强版）====="
    check_dependency
    check_input_files
    parse_doscar
    parse_poscar
    extract_tdos          # 提取TDOS（临时文件）
    extract_element_orbital_pdos  # 提取元素轨道分量PDOS（临时文件）
    user_interaction
    # 清理临时文件
    rm -f *.tmp
    echo -e "\n📊 分析完成！"
}

# 启动主程序
main