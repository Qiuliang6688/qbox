#!/usr/bin/env python3
import sys
import numpy as np

def read_poscar(filename):
    with open(filename, 'r') as f:
        lines = [line.strip() for line in f.readlines()]
    title = lines[0]
    scale = float(lines[1])
    lattice = []
    for i in range(2, 5):
        lattice.append([float(x) for x in lines[i].split()])
    elements = lines[5].split()
    atom_counts = [int(x) for x in lines[6].split()]
    total_atoms = sum(atom_counts)
    selective_dynamics = False
    coord_type = 'Direct'
    coord_start = 8
    if lines[7].lower() in ['selective dynamics']:
        selective_dynamics = True
        coord_type = lines[8].lower()
        coord_start = 9
    elif lines[7].lower() in ['direct', 'cartesian']:
        coord_type = lines[7].lower()
        coord_start = 8
    else:
        coord_type = 'Direct'
        coord_start = 8
    coords = []
    for i in range(coord_start, coord_start + total_atoms):
        if i < len(lines) and lines[i].strip():
            parts = lines[i].split()
            if len(parts) >= 3:
                coord = [float(parts[0]), float(parts[1]), float(parts[2])]
                flags = ["T", "T", "T"]
                if len(parts) >= 6 and selective_dynamics:
                    flags = [parts[3], parts[4], parts[5]]
                coords.append({'coord': coord, 'flags': flags})
    return {
        'title': title, 'scale': scale, 'lattice': lattice,
        'elements': elements, 'atom_counts': atom_counts,
        'coord_type': coord_type, 'coords': coords
    }

def write_poscar(data, filename, z_threshold):
    with open(filename, 'w') as f:
        f.write(data['title'] + '\n')
        f.write(f"  {data['scale']:.16f}\n")
        for vec in data['lattice']:
            f.write(f"  {vec[0]:>20.16f}  {vec[1]:>20.16f}  {vec[2]:>20.16f}\n")
        f.write('  ' + '  '.join(data['elements']) + '\n')
        f.write('  ' + '  '.join(map(str, data['atom_counts'])) + '\n')
        f.write('Selective dynamics\n')
        f.write(data['coord_type'] + '\n')
        fixed_count = 0
        for atom in data['coords']:
            x, y, z = atom['coord']
            if z < z_threshold:
                flags = "F F F"
                fixed_count += 1
            else:
                flags = "T T T"
            if data['coord_type'] == 'direct':
                f.write(f"  {x:>18.16f}  {y:>18.16f}  {z:>18.16f}  {flags}\n")
            else:
                f.write(f"  {x:>15.10f}  {y:>15.10f}  {z:>15.10f}  {flags}\n")
    return fixed_count

# 接收命令行参数（z_threshold）
if __name__ == '__main__':
    # 获取传入的z阈值
    z_threshold = float(sys.argv[1])
    # 执行核心逻辑
    poscar_data = read_poscar('POSCAR.backup')
    fixed_count = write_poscar(poscar_data, 'POSCAR', z_threshold)
    # 输出结果（保持和原逻辑一致的打印格式）
    print(f"Fixed {fixed_count} atoms (Z < {z_threshold})")