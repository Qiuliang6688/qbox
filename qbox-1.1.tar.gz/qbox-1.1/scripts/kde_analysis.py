#!/usr/bin/env python3
import sys
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
import pandas as pd
import warnings
warnings.filterwarnings('ignore') 

# ===================== 配置参数（和原逻辑完全一致） =====================
COLUMN_NAMES = ["d1", "d2"]  
SKIP_ROWS = 0 
CV1_RANGE = (0.0, 10.0)  
CV2_RANGE = (0.0, 10.0)  
OUTPUT_FIG_NAME = "KDE_Density.png" 
DPI = 300              
EPS = 1e-10  # 防止密度值为0

# ===================== 核心函数 =====================
def load_cv_data(file_path, col_names, skip_rows):
    """加载并清洗CV数据"""
    data = pd.read_csv(
        file_path,
        usecols=[1, 2], 
        skiprows=skip_rows,
        sep="\s+",      
        header=None,    
        names=col_names 
    )
    
    # 数据清洗：删除空值 + 过滤指定范围
    data = data.dropna()
    mask = (data[col_names[0]] >= CV1_RANGE[0]) & (data[col_names[0]] <= CV1_RANGE[1]) & \
           (data[col_names[1]] >= CV2_RANGE[0]) & (data[col_names[1]] <= CV2_RANGE[1])
    data = data[mask]
    
    print(f"Successfully loaded {len(data)} valid CV data points")
    return data[col_names[0]].values, data[col_names[1]].values

def calculate_kde(x, y):
    """计算2D KDE密度"""
    data_2d = np.vstack([x, y])
    kde = gaussian_kde(data_2d, bw_method="scott")
    
    # 生成网格
    x_grid = np.linspace(CV1_RANGE[0], CV1_RANGE[1], 200)
    y_grid = np.linspace(CV2_RANGE[0], CV2_RANGE[1], 200)
    X, Y = np.meshgrid(x_grid, y_grid)
    
    # 计算密度（加小epsilon避免0值）
    Z_density = kde(np.vstack([X.ravel(), Y.ravel()])).reshape(X.shape) + EPS
    return X, Y, Z_density

def save_density_data(X, Y, Z_density):
    """保存KDE密度数据到文件"""
    density_data = np.column_stack([X.ravel(), Y.ravel(), Z_density.ravel()])
    np.savetxt(
        "kde_density.dat", 
        density_data, 
        fmt="%.6f", 
        header="X(d_H275_O194, Å)  Y(d_H275_O271, Å)  Probability_Density", 
        comments='#'
    )
    print("Density data saved to: kde_density.dat")

def plot_kde_density(X, Y, Z_density):
    """绘制2D KDE密度图"""
    fig, ax = plt.subplots(1, 1, figsize=(8, 6), dpi=DPI)

    # 填充等高线 + 轮廓线
    contour = ax.contourf(X, Y, Z_density, levels=25, cmap="viridis", alpha=0.9)
    ax.contour(X, Y, Z_density, levels=10, colors="white", linewidths=0.7, alpha=0.8)
    
    # 颜色条
    cbar = plt.colorbar(contour, ax=ax, shrink=0.85)
    cbar.set_label("Probability Density", fontsize=12)
    
    # 坐标轴设置
    ax.set_xlabel(r"$d(\text{H275-O194})$ (Å)", fontsize=13)
    ax.set_ylabel(r"$d(\text{H275-O271})$ (Å)", fontsize=13)
    ax.set_title("2D KDE Density Plot of CVs", fontsize=14, pad=15)
    ax.set_xlim(CV1_RANGE)
    ax.set_ylim(CV2_RANGE)
    ax.grid(alpha=0.2, linestyle="--")

    # 保存图片
    plt.tight_layout()
    plt.savefig(OUTPUT_FIG_NAME, bbox_inches="tight")
    print(f"Figure saved to: {OUTPUT_FIG_NAME}")
    plt.close()

# ===================== 主执行逻辑 =====================
if __name__ == "__main__":
    try:
        # 从命令行参数获取COLVAR文件路径（替代原Bash变量）
        if len(sys.argv) != 2:
            print("ERROR: Please provide COLVAR file path as argument!")
            print("Usage: python3 kde_analysis.py <COLVAR_file_path>")
            sys.exit(1)
        CV_FILE_PATH = sys.argv[1]
        
        # 执行核心流程
        x, y = load_cv_data(CV_FILE_PATH, COLUMN_NAMES, SKIP_ROWS)
        X, Y, Z_density = calculate_kde(x, y)
        save_density_data(X, Y, Z_density)
        plot_kde_density(X, Y, Z_density)

        # 汇总输出
        print("="*50)
        print("Script execution completed! Key Results")
        print(f"1. Output figure: {OUTPUT_FIG_NAME}")
        print(f"2. Generated data file: kde_density.dat")
        print("="*50)

    except Exception as e:
        print(f"ERROR: {str(e)}")
        sys.exit(1)