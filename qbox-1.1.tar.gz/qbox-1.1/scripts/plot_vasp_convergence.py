#!/usr/bin/env python3
import sys
import matplotlib
matplotlib.use('Agg')  # 无GUI后端，适合服务器运行
import matplotlib.pyplot as plt

def plot_convergence_trends(min_lines):
    """绘制VASP能量和力的收敛趋势图"""
    # 读取能量和力数据（仅取前min_lines行）
    with open('energy.dat', 'r') as f:
        energies = [float(line.strip()) for line in f.readlines()[:min_lines]]
    with open('forces.dat', 'r') as f:
        forces = [float(line.strip()) for line in f.readlines()[:min_lines]]

    # 创建双子图
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))

    # 生成离子步数
    steps = range(1, len(energies) + 1)
    
    # 绘制能量趋势
    ax1.plot(steps, energies, 'bo-', markersize=3, linewidth=1)
    ax1.set_xlabel('Ionic Step')
    ax1.set_ylabel('Energy (eV)')
    ax1.set_title('VASP Energy Convergence Trend')
    ax1.grid(True, alpha=0.3)

    # 绘制最大力趋势
    ax2.plot(steps, forces, 'ro-', markersize=3, linewidth=1)
    ax2.set_xlabel('Ionic Step')
    ax2.set_ylabel('Maximum Force (eV/Å)')
    ax2.set_title('VASP Force Convergence Trend')
    ax2.grid(True, alpha=0.3)

    # 保存图片
    plt.tight_layout()
    plt.savefig('vasp_convergence.png', dpi=150, bbox_inches='tight')
    print("Chart saved as: vasp_convergence.png")

if __name__ == "__main__":
    # 从命令行参数获取min_lines
    if len(sys.argv) != 2:
        print("ERROR: Please provide min_lines as argument!")
        print("Usage: python3 plot_vasp_convergence.py <min_lines>")
        sys.exit(1)
    min_lines = int(sys.argv[1])
    # 执行绘图
    plot_convergence_trends(min_lines)