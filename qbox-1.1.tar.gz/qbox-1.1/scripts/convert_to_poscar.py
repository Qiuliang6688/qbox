#!/usr/bin/env python3
import sys
import os
import warnings
from collections import OrderedDict

# 忽略ASE的UserWarning（和原逻辑一致）
warnings.filterwarnings('ignore', category=UserWarning, module='ase.io.cif')

def convert_structure_to_poscar(input_file, output_file):
    """将任意结构文件转换为POSCAR（.vasp）格式"""
    try:
        from ase.io import read, write
        from ase.atoms import Atoms

        # 读取输入结构文件
        atoms = read(input_file)
        symbols = atoms.get_chemical_symbols()
        positions = atoms.get_positions()
        cell = atoms.get_cell()
        pbc = atoms.get_pbc()

        # 按元素排序原子（保持原逻辑的OrderedDict）
        element_count = OrderedDict()
        for sym in symbols:
            element_count[sym] = element_count.get(sym, 0) + 1

        sorted_symbols = []
        sorted_positions = []
        for elem in element_count.keys():
            elem_indices = [i for i, s in enumerate(symbols) if s == elem]
            for idx in elem_indices:
                sorted_symbols.append(elem)
                sorted_positions.append(positions[idx])

        # 构建新的Atoms对象
        new_atoms = Atoms(
            symbols=sorted_symbols,
            positions=sorted_positions,
            cell=cell,
            pbc=pbc
        )

        # 写入POSCAR文件（Cartesian格式）
        write(output_file, new_atoms, format='vasp', direct=False)
        print(f"Successfully converted to POSCAR: {output_file}")
        print(f"Coordinate type: Cartesian")

    except ImportError:
        print("ERROR: Please install ASE first: pip install ase")
        sys.exit(1)
    except Exception as e:
        print(f"Conversion failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    # 从命令行参数获取输入/输出文件路径（替代原Bash变量）
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    # 执行转换逻辑
    convert_structure_to_poscar(input_file, output_file)