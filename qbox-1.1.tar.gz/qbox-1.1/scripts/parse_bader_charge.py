#!/usr/bin/env python3
import re
import numpy as np
from collections import defaultdict

def parse_bader_results():
    """解析Bader电荷计算结果（ACF.dat），结合POSCAR/POTCAR统计电荷分布和转移"""
    try:
        # 从POSCAR提取元素和原子数量
        with open('POSCAR', 'r') as f:
            poscar_lines = f.readlines()
   
        elements_line = 5
        counts_line = 6
        
        elements = poscar_lines[elements_line].strip().split()
        atom_counts = list(map(int, poscar_lines[counts_line].strip().split()))
   
        # 构建原子索引到元素的映射
        atom_to_element = []
        for i, count in enumerate(atom_counts):
            element = elements[i]
            atom_to_element.extend([element] * count)

        # 解析ACF.dat的Bader电荷数据
        with open('ACF.dat', 'r') as f:
            acf_lines = f.readlines()

        data_lines = []
        for line in acf_lines:
            if line.strip() and not line.startswith('--') and not line.startswith('VACUUM'):
                parts = line.split()
                if len(parts) >= 7 and parts[0].isdigit():
                    data_lines.append(parts)
        
        # 检查原子数量匹配性
        if len(data_lines) != len(atom_to_element):
            print(f"Warning: Atom count mismatch! POSCAR: {len(atom_to_element)}, ACF.dat: {len(data_lines)}")
            return
        
        # 按元素统计电荷
        element_charges = defaultdict(list)
        for i, line_parts in enumerate(data_lines):
            if i < len(atom_to_element):
                element = atom_to_element[i]
                charge = float(line_parts[4])  # 第5列是Bader电荷
                element_charges[element].append(charge)
        
        # 打印电荷统计结果
        print("Bader charge analysis:")
        print("Element  Avg_Charge  Min_Charge  Max_Charge  Std_Dev")
        print("-------  ----------  ----------  ----------  -------")
        
        for element in sorted(element_charges.keys()):
            charges = element_charges[element]
            avg_charge = np.mean(charges)
            min_charge = np.min(charges)
            max_charge = np.max(charges)
            std_charge = np.std(charges)
            
            print(f"{element:7}  {avg_charge:10.3f}  {min_charge:10.3f}  {max_charge:10.3f}  {std_charge:7.3f}")
        
        # 电荷转移分析（结合POTCAR的价电子数）
        print("\nCharge transfer analysis (based on POTCAR valence electrons):")
        print("Assuming valence electrons from POTCAR (if available)")

        potcar_valence = {}
        try:
            with open('POTCAR', 'r') as f:
                potcar_content = f.read()
            
            # 按空行分割POTCAR中不同元素的段
            potcar_sections = re.split(r'\n\s*\n', potcar_content)
            for section in potcar_sections:
                # 匹配元素名称
                element_match = re.search(r'TITEL\s*=\s*PAW_[A-Za-z_]+\s+([A-Za-z]{1,3})', section)
                if element_match:
                    element = element_match.group(1)
                    # 匹配ZVAL（价电子数）
                    zval_match = re.search(r'ZVAL\s*=\s*([\d.]+)', section)
                    if zval_match:
                        potcar_valence[element] = float(zval_match.group(1))
        except:
            pass
        
        # 打印电荷转移结果
        if potcar_valence:
            print("Element  Valence_e  Avg_Bader_e  Charge_Transfer")
            print("-------  ---------  -----------  ---------------")
            for element in sorted(element_charges.keys()):
                if element in potcar_valence:
                    valence = potcar_valence[element]
                    avg_bader = np.mean(element_charges[element])
                    charge_transfer = avg_bader - valence  # 电荷转移量
                    print(f"{element:7}  {valence:9.1f}  {avg_bader:11.3f}  {charge_transfer:15.3f}")
        
    except Exception as e:
        print(f"ERROR parsing bader results: {e}")
        import traceback
        traceback.print_exc()

# 执行解析函数（和原逻辑一致）
if __name__ == '__main__':
    parse_bader_results()