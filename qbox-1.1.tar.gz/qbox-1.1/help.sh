#!/bin/bash

echo " "
path=`cd $(dirname $0); pwd -P`
    echo "#qbox:$path
     export qboxpath=$path
	 export qboxpbepath=*****
     export PATH=$path:\$PATH
     export PATH=$path/exefile/Tools/USERTooLs/vtstscripts:\$PATH" >> $HOME/.bashrc
    source $HOME/.bashrc
    echo -e "you have install qbox successfully\n"
	echo -e "vi ~/.bashrc"
	echo -e "change ***** to your PBE path"
	echo -e "source ~/.bashrc"
echo " "